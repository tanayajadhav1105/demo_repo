#!/bin/bash
python3 xmltosrt.py input.xml
